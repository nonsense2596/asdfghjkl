<?php
echo "Cpuinfo:<br>";
$handle = fopen("cpuinfo.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
       echo $line, "<br>"; 
    }

    fclose($handle);
} else {
   // let it fail silently
}
?>