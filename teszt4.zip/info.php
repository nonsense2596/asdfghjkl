<?php
echo php_uname(), "<br><br><br>";

echo "Cpuinfo:<br>";
$handle = fopen("cpuinfo.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
       echo $line, "<br>"; // process the line read.
    }

    fclose($handle);
} else {
   phpinfo(); // error opening the file.
}
echo "<br><br>Meminfo:<br>";
$handle = fopen("meminfo.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
       echo $line, "<br>"; // process the line read.
    }

    fclose($handle);
} else {
   phpinfo(); // error opening the file.
}
?>