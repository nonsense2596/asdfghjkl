<?php
echo "<br><br>Meminfo:<br>";
$handle = fopen("meminfo.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
       echo $line, "<br>"; 
    }

    fclose($handle);
} else {
   // let it fail silently
}
?>