<?php
echo php_uname();
?>